package com.rkc.userarchitectsih.dto;


import com.rkc.userarchitectsih.JsonClasses.Architect;

public class ArctitectResponse {

    private Architect[] eng;

    public Architect[] getEng() {
        return eng;
    }

    public void setEng(Architect[] eng) {
        this.eng = eng;
    }
}

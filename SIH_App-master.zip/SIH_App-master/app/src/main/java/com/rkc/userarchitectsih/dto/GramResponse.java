package com.rkc.userarchitectsih.dto;

public class GramResponse {
    private GramPanchayatDetails[] gram;

    public GramPanchayatDetails[] getGram() {
        return gram;
    }

    public void setGram(GramPanchayatDetails[] gram) {
        this.gram = gram;
    }
}
